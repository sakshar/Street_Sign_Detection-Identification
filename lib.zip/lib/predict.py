#! /usr/bin/env python

import argparse
import os, errno
import cv2
import numpy as np
from tqdm import tqdm
#from preprocessing import parse_annotation
#from utils import draw_boxes
#from frontend import YOLO
from . import preprocessing
from . import frontend
from . import utils
import zipfile
import json
import shutil
import glob
from skimage import io, color, exposure, transform
from keras.models import Sequential, model_from_json


from keras.models import load_model

os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"]="0"

NUM_CLASSES = 2
IMG_SIZE = 48

def preprocess_img(img):
    # Histogram normalization in y
    hsv = color.rgb2hsv(img)
    hsv[:,:,2] = exposure.equalize_hist(hsv[:,:,2])
    img = color.hsv2rgb(hsv)

    # central scrop
    min_side = min(img.shape[:-1])
    centre = img.shape[0]//2, img.shape[1]//2
    img = img[centre[0]-min_side//2:centre[0]+min_side//2,
              centre[1]-min_side//2:centre[1]+min_side//2,
              :]

    # rescale to standard size
    img = transform.resize(img, (IMG_SIZE, IMG_SIZE))

    # roll color axis to axis 0
    img = np.rollaxis(img,-1)

    return img


def predicting(args):
    main_data = args[0]
    dz=zipfile.ZipFile(main_data,'r')
    print(main_data)
	
    paths_list = main_data.split('\\')[:-1]
    main_path = ""
    for str1 in paths_list:
        main_path += str1 + "\\"	
    dz.extractall(main_path)
    test_path = main_path + 'train_yolo\\'
    test_annotation_path = main_path + "annotation\\"
    
    kitti = open('.\\lib\\kitti_simple_label.txt', 'r')
    image_class = {}
    for (count, line) in enumerate(kitti):
        line_splits = line.split(',')
        class_label = line_splits[-1]
        image_name = line_splits[0].split('/')[-1]
        if image_name not in image_class:
            image_class[image_name] = class_label		
    try:
        os.makedirs(os.path.join('.\\tmp','cropped'))
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise
    anchor_file = open('.\\tmp\\anchors.txt', 'r')
    anchor_line = anchor_file.readline()
    anchor_list = anchor_line.split()
    r = []
    for i in anchor_list:
        if i[0] == '[':
            r.append(float(i[1:-1]))
        else:
            r.append(float(i))
    anchor_file.close()
    ###############################
    #   Make the model 
    ###############################

    yolo = frontend.YOLO(backend             = "Full Yolo",
                input_size          = 800, 
                labels              = ["street_sign"], 
                max_box_per_image   = 10,
                anchors             = r)

    ###############################
    #   Load trained weights
    ###############################    

    yolo.load_weights(args[1])

    ###############################
    #   Predict bounding boxes 
    ###############################

    all_test_images_path = glob.glob(os.path.join(test_path, '*'))
    for image_path in all_test_images_path:
        image = cv2.imread(image_path)
        boxes = yolo.predict(image)
        image_h, image_w, _ = image.shape
        i = 1
        '''
        filedict={}
        file=open('test\gt.txt','r')
        for (count,line) in enumerate(file):
            (filen,classid)=line.split(',')
            filedict[filen]=classid[:-1]
        '''
        for box in boxes:
            xmin = int(box.xmin*image_w)
            ymin = int(box.ymin*image_h)
            xmax = int(box.xmax*image_w)
            ymax = int(box.ymax*image_h)
			
            img2 = image[ymin: ymax, xmin: xmax]
            new_image_path=image_path.split('\\')[-1]
            new_image_path=os.path.join('.\\tmp\\cropped',new_image_path)
            #cv2.imwrite(image_path[:-4] +'_'+ str(i) + image_path[-4:], img2)
            #print(new_image_path[:-4] +'_cropped_'+ str(i) +'-'+filedict[image_path.split('\\')[-1]]+ new_image_path[-4:])
            cv2.imwrite(new_image_path[:-4] +'_'+ str(i) + new_image_path[-4:], img2)
            i += 1
        #image = draw_boxes(image, boxes, ["street_sign"])
        #print(len(boxes), 'boxes are found')
        #cv2.imwrite(image_path[:-4] + '_detected' + image_path[-4:], image)
    from keras import backend as K
    K.set_image_data_format('channels_first')
    model=load_model(args[2])
    root_dir='.\\tmp\\cropped'
    imgs = []
    labels = []

    all_img_paths = glob.glob(os.path.join(root_dir, '*'))

    #print(all_img_paths)

    #for path in all_img_paths:
    #    path=path.replace('\\\\','/')
    for img_path in all_img_paths:
        try:
            img = preprocess_img(io.imread(img_path))
            label = image_class[img_path.split('_')[0].split('\\')[-1]+img_path[-4:]]
            label= int(label)
            imgs.append(img)
            labels.append(label)
        except (IOError, OSError):
            print('missed', img_path)
            pass

    X = np.array(imgs, dtype='float32')
    Y = np.eye(NUM_CLASSES, dtype='uint8')[labels]

    X_test=X
    y_test=Y
    y_pred = model.predict_classes(X_test)
    #print(y_pred)
    y_pred = np.eye(NUM_CLASSES)[y_pred]
    acc = np.sum(y_pred==y_test)/np.size(y_pred)
    print("Test accuracy = {}".format(acc))


    shutil.rmtree(os.path.join('.','tmp'))