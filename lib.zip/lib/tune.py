#! /usr/bin/env python

import argparse
import os
import numpy as np
#from preprocessing import parse_annotation
#from frontend import YOLO
#from utils import np_utils
from . import preprocessing
from . import frontend
from . import utils
import json
import random
import zipfile
from skimage import io, color, exposure, transform
from sklearn.cross_validation import train_test_split
import glob
import h5py

#%matplotlib inline

NUM_CLASSES = 2
IMG_SIZE = 48

os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"]="0"

# functions vfor classifier
def preprocess_img(img):
    # Histogram normalization in y
    hsv = color.rgb2hsv(img)
    hsv[:,:,2] = exposure.equalize_hist(hsv[:,:,2])
    img = color.hsv2rgb(hsv)

    # central scrop
    min_side = min(img.shape[:-1])
    centre = img.shape[0]//2, img.shape[1]//2
    img = img[centre[0]-min_side//2:centre[0]+min_side//2,
              centre[1]-min_side//2:centre[1]+min_side//2,
              :]

    # rescale to standard size
    img = transform.resize(img, (IMG_SIZE, IMG_SIZE))

    # roll color axis to axis 0
    img = np.rollaxis(img,-1)

    return img


def get_class(img_path):
    return int(img_path.split('\\')[-2])

def cnn_model(n):
    from keras.preprocessing.image import ImageDataGenerator
    from keras.models import Sequential, model_from_json
    from keras.layers.core import Dropout, Flatten, Dense, Activation
    from keras.layers.convolutional import Conv2D
    from keras.layers.pooling import MaxPooling2D
 
    from keras.optimizers import SGD
    from keras.utils import np_utils
    from keras.callbacks import LearningRateScheduler, ModelCheckpoint

    from keras.models import load_model

    from matplotlib import pyplot as plt
    from keras import backend as K
    K.set_image_data_format('channels_first')
    model = Sequential()
	
    model.add(Conv2D(32, (3, 3), padding='same',
                     input_shape=(3, IMG_SIZE, IMG_SIZE),
                     activation='relu'))
    model.add(Conv2D(32, (3, 3), activation='relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Dropout(0.2))

    model.add(Conv2D(64, (3, 3), padding='same',
                     activation='relu'))
    model.add(Conv2D(64, (3, 3), activation='relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Dropout(0.2))

    if n == 1:
        model.add(Conv2D(128, (3, 3), padding='same',
                         activation='relu'))
        model.add(Conv2D(128, (3, 3), activation='relu'))
        model.add(MaxPooling2D(pool_size=(2, 2)))
        model.add(Dropout(0.2))
        model.add(Flatten())
        model.add(Dense(512, activation='relu'))
        model.add(Dropout(0.5))
    elif n == 2:
        model.add(Flatten())
        model.add(Dense(512, activation='relu'))
        model.add(Dropout(0.5))
    elif n == 3:
        model.add(Flatten())	
    model.add(Dense(NUM_CLASSES, activation='softmax'))
    return model

lr = 0.01
def lr_schedule(epoch):
    return lr*(0.1**int(epoch/10))
	
def train_classifier(train_path_cnn, model_file, n):
    # preprocess all training image into a numpy array
    from keras.preprocessing.image import ImageDataGenerator
    from keras.models import Sequential, model_from_json
    from keras.layers.core import Dropout
    from keras.layers.convolutional import Conv2D
    from keras.layers.pooling import MaxPooling2D
 
    from keras.optimizers import SGD
    from keras.utils import np_utils
    from keras.callbacks import LearningRateScheduler, ModelCheckpoint

    from keras.models import load_model

    from matplotlib import pyplot as plt
    from keras import backend as K
    K.set_image_data_format('channels_first')
    try:
        with  h5py.File('X.h5') as hf: 
            X, Y = hf['imgs'][:], hf['labels'][:]
        print("Loaded images from X.h5")
    
    except (IOError,OSError, KeyError):  
        print("Error in reading X.h5. Processing all images...")
        #root_dir = 'GTSRB/Final_Training/Images/'
        #root_dir = 'E:/road sign detection/Training/'
        root_dir= train_path_cnn
        imgs = []
        labels = []

        all_img_paths = glob.glob(os.path.join(root_dir, '*\*.ppm'))
    
        for path in all_img_paths:
            path=path.replace('\\\\','/')
        np.random.shuffle(all_img_paths)
        for img_path in all_img_paths:
            try:
                img = preprocess_img(io.imread(img_path))
                label = get_class(img_path)
                imgs.append(img)
                labels.append(label)

                if len(imgs)%1000 == 0: print("Processed {}/{}".format(len(imgs), len(all_img_paths)))
            except (IOError, OSError):
                print('missed', img_path)
                pass

        X = np.array(imgs, dtype='float32')
        Y = np.eye(NUM_CLASSES, dtype='uint8')[labels]

        with h5py.File('X.h5','w') as hf:
            hf.create_dataset('imgs', data=X)
            hf.create_dataset('labels', data=Y)
    
    model = cnn_model(n)
    # let's train the model using SGD + momentum (how original).
    sgd = SGD(lr=lr, decay=1e-6, momentum=0.9, nesterov=True)
    model.compile(loss='categorical_crossentropy',
              optimizer=sgd,
              metrics=['accuracy'])
			   
			   
    batch_size = 32
    nb_epoch = 10

    history = model.fit(X, Y,
          batch_size=batch_size,
          epochs=nb_epoch,
          validation_split=0.2,
          shuffle=True,
          callbacks=[LearningRateScheduler(lr_schedule),
                    ModelCheckpoint(model_file,save_best_only=True)]
            )
    #return history['val_acc'], history['val_loss']
    return history
# generate anchors

#argparser = argparse.ArgumentParser()
def IOU(ann, centroids):
    w, h = ann
    similarities = []

    for centroid in centroids:
        c_w, c_h = centroid

        if c_w >= w and c_h >= h:
            similarity = w*h/(c_w*c_h)
        elif c_w >= w and c_h <= h:
            similarity = w*c_h/(w*h + (c_w-w)*c_h)
        elif c_w <= w and c_h >= h:
            similarity = c_w*h/(w*h + c_w*(c_h-h))
        else: #means both w,h are bigger than c_w and c_h respectively
            similarity = (c_w*c_h)/(w*h)
        similarities.append(similarity) # will become (k,) shape

    return np.array(similarities)

def avg_IOU(anns, centroids):
    n,d = anns.shape
    sum = 0.

    for i in range(anns.shape[0]):
        sum+= max(IOU(anns[i], centroids))

    return sum/n

def print_anchors(centroids):
    anchors = centroids.copy()

    widths = anchors[:, 0]
    sorted_indices = np.argsort(widths)
    anchor_list = []
    r = "anchors: ["
    for i in sorted_indices[:-1]:
        r += '%0.2f,%0.2f, ' % (anchors[i,0], anchors[i,1])
        anchor_list.append(anchors[i,0])
        anchor_list.append(anchors[i,1])
    #there should not be comma after last anchor, that's why
    r += '%0.2f,%0.2f' % (anchors[sorted_indices[-1:],0], anchors[sorted_indices[-1:],1])
    r += "]"
    anchor_list.append(anchors[sorted_indices[-1:],0])
    anchor_list.append(anchors[sorted_indices[-1:],1])	

    print(r)
    return anchor_list

def run_kmeans(ann_dims, anchor_num):
    ann_num = ann_dims.shape[0]
    iterations = 0
    prev_assignments = np.ones(ann_num)*(-1)
    iteration = 0
    old_distances = np.zeros((ann_num, anchor_num))

    indices = [random.randrange(ann_dims.shape[0]) for i in range(anchor_num)]
    centroids = ann_dims[indices]
    anchor_dim = ann_dims.shape[1]

    while True:
        distances = []
        iteration += 1
        for i in range(ann_num):
            d = 1 - IOU(ann_dims[i], centroids)
            distances.append(d)
        distances = np.array(distances) # distances.shape = (ann_num, anchor_num)

        print("iteration {}: dists = {}".format(iteration, np.sum(np.abs(old_distances-distances))))

        #assign samples to centroids
        assignments = np.argmin(distances,axis=1)

        if (assignments == prev_assignments).all() :
            return centroids

        #calculate new centroids
        centroid_sums=np.zeros((anchor_num, anchor_dim), np.float)
        for i in range(ann_num):
            centroid_sums[assignments[i]]+=ann_dims[i]
        for j in range(anchor_num):
            centroids[j] = centroid_sums[j]/(np.sum(assignments==j) + 1e-6)

        prev_assignments = assignments.copy()
        old_distances = distances.copy()


	
def tuning(args):
	
    #config_path = args.conf

    #with open(config_path) as config_buffer:    
    #    config = json.loads(config_buffer.read())
    #os.chdir('.\lib')	
    train_cycle = [2, 4, 8]
    yolo_epochs = [1, 2, 3]
    model_no = [1, 2, 3]
    main_data = args[0]
    dz=zipfile.ZipFile(main_data,'r')
    print(main_data)
	
    paths_list = main_data.split('\\')[:-1]
    main_path = ""
    for str1 in paths_list:
        main_path += str1 + "\\"	
    dz.extractall(main_path)
    train_path = main_path + 'train_yolo\\'
    train_annotation_path = main_path + "annotation\\"
	
    main_data = args[1]
    dz=zipfile.ZipFile(main_data,'r')
    print(main_data)
	
    paths_list = main_data.split('\\')[:-1]
    main_path2 = ""
    for str1 in paths_list:
        main_path2 += str1 + "\\"	
    dz.extractall(main_path2)
    valid_path = main_path2 + 'train_yolo\\'
    valid_annotation_path = main_path2 + "annotation\\"
    labels_config = ["street_sign"]
	
    ###############################
    #   Parse the annotations 
    ###############################

    # parse annotations of the training set
    #train_imgs, train_labels = parse_annotation(config['train']['train_annot_folder'], 
    #                                            config['train']['train_image_folder'], 
    #                                            config['model']['labels'])
    train_imgs, train_labels = preprocessing.parse_annotation(train_annotation_path, 
                                                train_path, 
                                                labels_config)
    										
    # generating anchors
    #config_path = args.conf
    #num_anchors = args.anchors  
    num_anchors = 5	
    grid_w = 800/32
    grid_h = 800/32

    # run k_mean to find the anchors
    annotation_dims = []
    for image in train_imgs:
        cell_w = image['width']/grid_w
        cell_h = image['height']/grid_h

        for obj in image['object']:
            relative_w = (float(obj['xmax']) - float(obj['xmin']))/cell_w
            relatice_h = (float(obj["ymax"]) - float(obj['ymin']))/cell_h
            annotation_dims.append(tuple(map(float, (relative_w,relatice_h))))

    annotation_dims = np.array(annotation_dims)
    centroids = run_kmeans(annotation_dims, num_anchors)

    # write anchors to file
    print('\naverage IOU for', num_anchors, 'anchors:', '%0.2f' % avg_IOU(annotation_dims, centroids))
    print("centroids:")
    r = print_anchors(centroids)
    
    # parse annotations of the validation set, if any, otherwise split the training set
    #if os.path.exists(config['valid']['valid_annot_folder']):
    valid_imgs, valid_labels = preprocessing.parse_annotation(valid_annotation_path, 
                                                valid_path, 
                                                labels_config)
    train_imgs, train_labels = preprocessing.parse_annotation(train_annotation_path, 
                                                train_path, 
                                                labels_config)
    #else:
    #train_valid_split = int(0.99*len(train_imgs))
    #np.random.shuffle(train_imgs)

    #valid_imgs = train_imgs[train_valid_split:]
    #train_imgs = train_imgs[:train_valid_split]

    if len(labels_config) > 0:
        overlap_labels = set(labels_config).intersection(set(train_labels.keys()))

        print('Seen labels:\t', train_labels)
        print('Given labels:\t', labels_config)
        print('Overlap labels:\t', overlap_labels)           

        if len(overlap_labels) < len(labels_config):
            print('Some labels have no annotations! Please revise the list of labels in the config.json file!')
            return
    else:
        print('No labels are provided. Train on all seen labels.')
        labels_config = train_labels.keys()
        
    ###############################
    #   Construct the model 
    ###############################
    
    max_box_per_image = 10
    # [0.85,0.77, 1.24,1.06, 1.80,1.55, 2.55,2.20, 3.88,3.23]
    yolo = frontend.YOLO(backend             = "Full Yolo",
                input_size          = 800, 
                labels              = ["street_sign"], 
                max_box_per_image   = max_box_per_image,
                anchors             = r)

    ###############################
    #   Load the pretrained weights (if any) 
    ###############################    

    #if os.path.exists(config['train']['pretrained_weights']):
    #    print("Loading pre-trained weights in", config['train']['pretrained_weights'])
    #    yolo.load_weights(config['train']['pretrained_weights'])

    ###############################
    #   Start the training process 
    ###############################

    #train_ts = 1
    #epochs	= 1
    result_f = open('tuning_results.txt','w')
    result_f.write('train_times \t yolo_epochs \t cnn_model \t mAp \t train_acc \t val_acc\n')
    best_hyperparameter = [0, 0, 0]
    max_mAp = -9999999.9999
    max_val_acc = 0	
    for train_ts in train_cycle:
        epochs = 1
        cnn_model_no = 1
        mAp = yolo.train(train_imgs         = train_imgs,
                   valid_imgs         = valid_imgs,
                   train_times        = train_ts,
                   valid_times        = 1,
                   nb_epochs          = epochs, 
                   learning_rate      = 1e-4, 
                   batch_size         = 1,
                   warmup_epochs      = 3,
                   object_scale       = 5.0,
                   no_object_scale    = 1.0,
                   coord_scale        = 1.0,
                   class_scale        = 1.0,
                   saved_weights_name = ".\\tmp\\model1.h5",
                   debug              = False)

        # training classifier
        train_path_cnn = main_path + 'train_cnn\\'
        history = train_classifier(train_path_cnn, ".\\tmp\\model2.h5", cnn_model_no)
        print(history.history['val_acc'])
        val_acc = history.history['val_acc'][-1] 
        if mAp > max_mAp:
            max_mAp = mAp
            best_hyperparameter[0] = train_ts
            best_hyperparameter[1] = epochs
        if val_acc > max_val_acc:
            max_val_acc = val_acc
            best_hyperparameter[2] = cnn_model_no
        result = str(str(train_ts)+'\t'+str(epochs)+'\t'+str(cnn_model_no)+'\t'+str(mAp)+'\t'+str(history.history['acc'][-1])+'\t'+str(val_acc)+'\n')
        result_f.write(result)			
    for epochs in yolo_epochs:
        train_ts = 4
        cnn_model_no = 1
        mAp = yolo.train(train_imgs         = train_imgs,
                   valid_imgs         = valid_imgs,
                   train_times        = train_ts,
                   valid_times        = 1,
                   nb_epochs          = epochs, 
                   learning_rate      = 1e-4, 
                   batch_size         = 1,
                   warmup_epochs      = 3,
                   object_scale       = 5.0,
                   no_object_scale    = 1.0,
                   coord_scale        = 1.0,
                   class_scale        = 1.0,
                   saved_weights_name = ".\\tmp\\model1.h5",
                   debug              = False)

        # training classifier
        train_path_cnn = main_path + 'train_cnn\\'
        history = train_classifier(train_path_cnn, ".\\tmp\\model2.h5", cnn_model_no)
        print(history.history['val_acc'])
        val_acc = history.history['val_acc'][-1]
        if mAp > max_mAp:
            max_mAp = mAp
            best_hyperparameter[0] = train_ts
            best_hyperparameter[1] = epochs
        if val_acc > max_val_acc:
            max_val_acc = val_acc
            best_hyperparameter[2] = cnn_model_no
        result = str(str(train_ts)+'\t'+str(epochs)+'\t'+str(cnn_model_no)+'\t'+str(mAp)+'\t'+str(history.history['acc'][-1])+'\t'+str(val_acc)+'\n')
        result_f.write(result)
    train_ts = 4
    epochs = 2
    mAp = yolo.train(train_imgs         = train_imgs,
               valid_imgs         = valid_imgs,
               train_times        = train_ts,
               valid_times        = 1,
               nb_epochs          = epochs, 
               learning_rate      = 1e-4, 
               batch_size         = 1,
               warmup_epochs      = 3,
               object_scale       = 5.0,
               no_object_scale    = 1.0,
               coord_scale        = 1.0,
               class_scale        = 1.0,
               saved_weights_name = ".\\tmp\\model1.h5",
               debug              = False)
    if mAp > max_mAp:
        max_mAp = mAp
        best_hyperparameter[0] = train_ts
        best_hyperparameter[1] = epochs
    for cnn_model_no in model_no:
        # training classifier
        train_path_cnn = main_path + 'train_cnn\\'
        history = train_classifier(train_path_cnn, ".\\tmp\\model2.h5", cnn_model_no)
        print(history.history['val_acc'])
        val_acc = history.history['val_acc'][-1]
        if val_acc > max_val_acc:
            max_val_acc = val_acc
            best_hyperparameter[2] = cnn_model_no
        result = str(str(train_ts)+'\t'+str(epochs)+'\t'+str(cnn_model_no)+'\t'+str(mAp)+'\t'+str(history.history['acc'][-1])+'\t'+str(val_acc)+'\n')
        result_f.write(result)
    result_f.close()		
    
    if os.path.isfile('.\\tmp\\model1.h5'):
        os.remove('.\\tmp\\model1.h5')
    if os.path.isfile('.\\tmp\\model2.h5'):
        os.remove('.\\tmp\\model2.h5')
    if os.path.isfile('.\\X.h5'):
        os.remove('.\\X.h5')
    param_f = open('hyperparameter.txt','w')
    param = str(best_hyperparameter[0])+' '+str(best_hyperparameter[1])+' '+str(best_hyperparameter[2])
    param_f.write(param)
    param_f.close()