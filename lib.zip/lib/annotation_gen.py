import numpy as np
import pandas as pd
#
# <annotation verified="yes">
# 	<folder>images</folder>
# 	<filename>raccoon-1.jpg</filename>
# 	<path>/Users/datitran/Desktop/raccoon/images/raccoon-1.jpg</path>
# 	<source>
# 		<database>Unknown</database>
# 	</source>
# 	<size>
# 		<width>650</width>
# 		<height>417</height>
# 		<depth>3</depth>
# 	</size>
# 	<segmented>0</segmented>
# 	<object>
# 		<name>raccoon</name>
# 		<pose>Unspecified</pose>
# 		<truncated>0</truncated>
# 		<difficult>0</difficult>
# 		<bndbox>
# 			<xmin>81</xmin>
# 			<ymin>88</ymin>
# 			<xmax>522</xmax>
# 			<ymax>408</ymax>
# 		</bndbox>
# 	</object>
# </annotation>


dataFrame=pd.read_csv('kitti_simple_label.txt',',')
annotation_matrix=dataFrame.as_matrix()
for annotation in annotation_matrix:
    image_filename=annotation[0]
    annotation_filename=image_filename[image_filename.find('/'):image_filename.rfind('.')]+'.xml'
    #print(image_filename,annotation_filename)
    with open('annotation/'+annotation_filename,'w') as f:
        f.write(' <annotation verified=\"yes\">\n')
        f.write('\t<folder>train</folder>\n')
        f.write('\t<filename>'+image_filename[image_filename.find('/')+1:]+'</filename>\n')
        f.write('\t<path>D:/ml-project-helper/keras-yolo/keras-yolo2/'+image_filename+'</path>\n')
        f.write('\t<source>\n\t\t<database>Unknown</database>\n\t</source>\n')
        f.write('\t<size>\n\t\t<width>800</width>\n\t\t<height>800</height>\n\t\t<depth>3</depth>\n\t</size>\n')
        f.write('\t<segmented>0</segmented>\n')
        f.write('\t<object>\n\t\t<name>'+annotation[5]+'</name>\n\t\t<pose>Unspecified</pose>\n\t\t<truncated>0</truncated>\n\t\t<difficult>0</difficult>\n')
        f.write('\t\t<bndbox>\n')
        f.write('\t\t\t<xmin>'+str(annotation[1])+'</xmin>\n')
        f.write('\t\t\t<ymin>'+str(annotation[2])+'</ymin>\n')
        f.write('\t\t\t<xmax>'+str(annotation[3])+'</xmax>\n')
        f.write('\t\t\t<ymax>'+str(annotation[4])+'</ymax>\n')
        f.write('\t\t</bndbox>\n')
        f.write('\t	</object>\n')
        f.write('</annotation>')

    f.close()
