import pandas as pd 
import cv2
import  random
import numpy as np

dataFrame=pd.read_csv('kitti_simple_label.txt',sep=',',header=None)
print(dataFrame)
input_data=dataFrame.as_matrix()
output_data=[]
old_files=[]
for data in input_data:
    output_data.append(data)
    old_files.append(data[0])


def writeFile(filename,image,col,row,dx,dy):
    if filename in old_files:
        return
    dst = cv2.resize(image, (col + dy, row + dx))
    cv2.imwrite(outfile, dst)
    new_data=[]
    new_data.append(outfile)
    new_data.append(int(data[1] / col * (col + dy)))
    new_data.append(int(data[2] / row * (row + dx)))
    new_data.append(int(data[3] / col * (col + dy)))
    new_data.append(int(data[4] / row * (row + dx)))
    new_data.append(data[5])
    new_data=np.asanyarray(new_data)
    output_data.append(new_data)


    


for data  in input_data:
    print(data[0])
    image=cv2.imread(data[0])
    row = image.shape[0]
    col = image.shape[1]

    '''-x'''
    dx = -random.randint(15, 40)
    dy = 0
    
    outfile = data[0] + '.1.png'
    writeFile(outfile,image,col,row,dx,dy)
    
   


    '''+x'''
    dx = random.randint(15, 40)
    dy = 0
    outfile = data[0] + '.2.png'
    writeFile(outfile,image,col,row,dx,dy)



    '''-y'''
    dx = 0
    dy = -random.randint(15, 15)
    outfile = data[0] + '.3.png'
    writeFile(outfile,image,col,row,dx,dy)


    ''''''
    dx = 0
    dy = random.randint(15, 40)
    outfile = data[0] + '.4.png'
    writeFile(outfile,image,col,row,dx,dy)




    dx = random.randint(15, 40)
    dy = random.randint(15, 40)
    outfile = data[0] + '.5.png'
    writeFile(outfile,image,col,row,dx,dy)



    dx = -random.randint(15, 40)
    dy = random.randint(15, 40)
    outfile = data[0] + '.6.png'
    writeFile(outfile,image,col,row,dx,dy)



    dx = -random.randint(15, 40)
    dy = -random.randint(15, 40)
    outfile = data[0] + '.7.png'
    writeFile(outfile,image,col,row,dx,dy)



    dx = random.randint(15, 40)
    dy = -random.randint(15, 40)
    outfile = data[0] + '.8.png'
    writeFile(outfile,image,col,row,dx,dy)


    


with open('kitti_simple_label.txt','w') as f:
    for data in output_data:
        print('w',data[0])
        s=''
        for i in range(5):
            #print(data[i])
            s=s+str(data[i])+','
        s+=data[5]+'\n'
        f.write(s)




